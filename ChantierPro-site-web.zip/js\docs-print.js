/* =========================================================
   ChantierPro — documents imprimables (devis, BC, décomptes…)
   ========================================================= */
(function () {
  'use strict';
  const App = window.App;
  const { esc, money, num, fmtDate, n } = App;

  function soc() { return App.settings().societe; }

  function logoSrc(dataUrl) {
    if (!dataUrl) return '';
    if (/^(data:|blob:|https?:|file:)/i.test(dataUrl)) return dataUrl;
    try { return new URL(dataUrl, window.location.href).href; } catch (e) { return dataUrl; }
  }

  function companyHTML() {
    const s = soc();
    const logo = s.logo && s.logo.dataUrl
      ? '<img class="doc-logo" src="' + esc(logoSrc(s.logo.dataUrl)) + '" alt="Logo ' + esc(s.nom || '') + '">'
      : '';
    return '<div>' + logo + '<h1>' + esc(s.nom || 'Mon entreprise') + '</h1><p>' +
      esc(s.adresse || '') + '<br>' +
      esc((s.cp || '') + ' ' + (s.ville || '')) + '<br>' +
      (s.tel ? 'Tél. ' + esc(s.tel) + '<br>' : '') +
      (s.email ? esc(s.email) + '<br>' : '') +
      (s.siret ? 'SIRET ' + esc(s.siret) + ' — TVA ' + esc(s.tva || '') : '') + '</p></div>';
  }

  function docHead(label, numero, date, extra, chantier) {
    return '<div class="doc-head">' + companyHTML() +
      '<div class="doc-type"><h2>' + esc(label) + '</h2><p><strong>' + esc(numero) + '</strong><br>' +
      'Date : ' + fmtDate(date) + (extra ? '<br>' + extra : '') +
      (chantier ? '<br>Chantier : ' + esc(chantier.nom) : '') + '</p></div></div>';
  }

  function party(title, html) {
    return '<div class="party"><h4>' + esc(title) + '</h4>' + html + '</div>';
  }

  function table(lines, cols) {
    return '<table class="lines"><thead><tr>' +
      cols.map(function (c) { return '<th class="' + (c.r ? 'r' : '') + '">' + esc(c.label) + '</th>'; }).join('') +
      '</tr></thead><tbody>' + lines + '</tbody></table>';
  }

  function totals(rows) {
    return '<div class="totals">' + rows.map(function (r) {
      return '<div class="' + (r.strong ? 'net' : '') + '"><span>' + esc(r.label) + '</span><b>' + esc(r.value) + '</b></div>';
    }).join('') + '</div>';
  }

  function chantierOf(doc) { return doc.chantierId ? App.db.find('chantiers', doc.chantierId) : null; }

  function chantierAddress(ch) {
    if (!ch) return '';
    return esc(ch.adresse || '') + (ch.cp || ch.ville ? '<br>' + esc((ch.cp || '') + ' ' + (ch.ville || '')) : '');
  }

  /* ---------------- Devis ---------------- */
  App.printDevis = function (id) {
    const d = App.db.find('devis', id);
    if (!d) return;
    const ch = chantierOf(d);
    const t = App.calc.devis(d);
    const lines = (d.lignes || []).map(function (l) {
      return '<tr><td>' + esc(l.designation) + '</td><td>' + esc(l.unite || '') + '</td><td class="r">' + num(l.quantite) +
        '</td><td class="r">' + money(l.pu) + '</td><td class="r">' + money(n(l.quantite) * n(l.pu)) + '</td></tr>';
    }).join('');
    const rows = [
      { label: 'Total HT brut', value: money(t.htBrut) },
      { label: 'Remise (' + num(d.remise) + ' %)', value: '− ' + money(t.remise) },
      { label: 'Total HT', value: money(t.ht) },
      { label: 'TVA (' + num(d.tva) + ' %)', value: money(t.tva) },
      { label: 'Total TTC', value: money(t.ttc), strong: true }
    ];
    const html = docHead('DEVIS', d.numero, d.date, 'Validité : ' + fmtDate(d.validite), ch) +
      '<div class="doc-parties">' +
        party('Client', '<p><strong>' + esc(d.client || (ch && ch.client) || '') + '</strong><br>' + (ch ? chantierAddress(ch) : '') + '</p>') +
        party('Chantier', ch ? '<p><strong>' + esc(ch.code || '') + '</strong><br>' + esc(ch.nom) + '<br>' + chantierAddress(ch) + '</p>' : '<p>—</p>') +
      '</div>' +
      table(lines, [
        { label: 'Désignation' }, { label: 'Unité' }, { label: 'Qté', r: true }, { label: 'P.U. HT', r: true }, { label: 'Montant HT', r: true }
      ]) +
      totals(rows) +
      (d.notes ? '<div class="notes"><strong>Notes :</strong> ' + esc(d.notes) + '</div>' : '') +
      '<div class="notes">' + esc(App.settings().mentionsDevis) + '</div>' +
      '<div class="sign"><div>Date et signature du client<br><em>Bon pour accord</em></div><div>Pour ' + esc(soc().nom) + '</div></div>';
    App.printHTML('Devis ' + d.numero, html);
  };

  /* ---------------- Bon de commande ---------------- */
  App.printCommande = function (id) {
    const c = App.db.find('commandes', id);
    if (!c) return;
    const ch = chantierOf(c);
    const f = App.db.find('fournisseurs', c.fournisseurId);
    const t = App.calc.commande(c);
    const lines = (c.lignes || []).map(function (l) {
      return '<tr><td>' + esc(l.designation) + '</td><td>' + esc(l.unite || '') + '</td><td class="r">' + num(l.quantite) +
        '</td><td class="r">' + money(l.pu) + '</td><td class="r">' + money(n(l.quantite) * n(l.pu)) + '</td></tr>';
    }).join('');
    const rows = [
      { label: 'Total HT', value: money(t.ht) },
      { label: 'TVA (' + num(c.tva) + ' %)', value: money(t.tva) },
      { label: 'Total TTC', value: money(t.ttc), strong: true }
    ];
    const html = docHead('BON DE COMMANDE', c.numero, c.date, 'Livraison souhaitée : ' + fmtDate(c.dateLivraison), ch) +
      '<div class="doc-parties">' +
        party('Fournisseur', f ? '<p><strong>' + esc(f.nom) + '</strong><br>' + esc(f.contact || '') + '<br>' + esc(f.adresse || '') + '<br>' + esc((f.cp || '') + ' ' + (f.ville || '')) + '<br>' + esc(f.tel || '') + (f.email ? '<br>' + esc(f.email) : '') + '</p>' : '<p>—</p>') +
        party('Adresse de livraison', ch ? '<p><strong>' + esc(ch.nom) + '</strong><br>' + chantierAddress(ch) + '<br>Contact : ' + esc(ch.chef || '') + '</p>' : '<p>—</p>') +
      '</div>' +
      table(lines, [
        { label: 'Désignation' }, { label: 'Unité' }, { label: 'Qté', r: true }, { label: 'P.U. HT', r: true }, { label: 'Montant HT', r: true }
      ]) +
      totals(rows) +
      (c.notes ? '<div class="notes"><strong>Instructions :</strong> ' + esc(c.notes) + '</div>' : '') +
      '<div class="notes">' + esc(App.settings().mentionsCommande) + '</div>' +
      '<div class="sign"><div>Le fournisseur</div><div>Pour ' + esc(soc().nom) + '</div></div>';
    App.printHTML('Bon de commande ' + c.numero, html);
  };

  /* ---------------- Décompte client ---------------- */
  App.printDecompte = function (id) {
    const d = App.db.find('decomptes', id);
    if (!d) return;
    const ch = chantierOf(d);
    const t = App.calc.decompte(d);
    const lines = (d.lignes || []).map(function (l) {
      const mt = n(l.quantite) * n(l.pu) * App.clamp(n(l.avancement), 0, 100) / 100;
      return '<tr><td>' + esc(l.designation) + '</td><td>' + esc(l.unite || '') + '</td><td class="r">' + num(l.quantite) +
        '</td><td class="r">' + money(l.pu) + '</td><td class="r">' + num(l.avancement) + ' %</td><td class="r">' + money(mt) + '</td></tr>';
    }).join('');
    const rows = [
      { label: 'Total HT', value: money(t.ht) },
      { label: 'Retenue de garantie (' + num(d.retenue) + ' %)', value: '− ' + money(t.retenue) },
      { label: 'TVA (' + num(d.tva) + ' %)', value: money(t.tva) },
      { label: 'Net à payer', value: money(t.net), strong: true }
    ];
    const html = docHead('DÉCOMPTE', d.numero, d.date, 'Période : ' + esc(d.periode || '—'), ch) +
      '<div class="doc-parties">' +
        party('Maître d\'ouvrage', '<p><strong>' + esc(d.client || (ch && ch.client) || '') + '</strong><br>' + (ch ? chantierAddress(ch) : '') + '</p>') +
        party('Chantier', ch ? '<p><strong>' + esc(ch.code || '') + '</strong><br>' + esc(ch.nom) + '<br>' + chantierAddress(ch) + '</p>' : '<p>—</p>') +
      '</div>' +
      table(lines, [
        { label: 'Désignation' }, { label: 'Unité' }, { label: 'Qté', r: true }, { label: 'P.U. HT', r: true }, { label: 'Avanc.', r: true }, { label: 'Montant HT', r: true }
      ]) +
      totals(rows) +
      (d.notes ? '<div class="notes"><strong>Observations :</strong> ' + esc(d.notes) + '</div>' : '') +
      '<div class="notes">' + esc(App.settings().mentionsDecompte) + '</div>' +
      '<div class="sign"><div>Le maître d\'ouvrage</div><div>Pour ' + esc(soc().nom) + '</div></div>';
    App.printHTML('Décompte ' + d.numero, html);
  };

  /* ---------------- Situation sous-traitant ---------------- */
  App.printSituation = function (id) {
    const s = App.db.find('situations', id);
    if (!s) return;
    const ch = chantierOf(s);
    const st = App.db.find('sousTraitants', s.sousTraitantId);
    const t = App.calc.situation(s);
    const lines = (s.lignes || []).map(function (l) {
      const cumul = n(l.montantMarche) * App.clamp(n(l.pctCumule), 0, 100) / 100;
      const prec = n(l.montantMarche) * App.clamp(n(l.pctPrecedent), 0, 100) / 100;
      return '<tr><td>' + esc(l.designation) + '</td><td class="r">' + money(l.montantMarche) + '</td><td class="r">' + num(l.pctPrecedent) +
        ' %</td><td class="r">' + num(l.pctCumule) + ' %</td><td class="r">' + money(cumul) + '</td><td class="r">' + money(cumul - prec) + '</td></tr>';
    }).join('');
    const rows = [
      { label: 'Montant du marché', value: money(t.marche) },
      { label: 'Travaux cumulés', value: money(t.cumul) },
      { label: 'Déjà facturé', value: '− ' + money(t.precedent) },
      { label: 'Travaux de la période', value: money(t.periode) },
      { label: 'Retenue de garantie (' + num(s.retenue) + ' %)', value: '− ' + money(t.retenue) },
      { label: 'TVA (' + num(s.tva) + ' %)', value: money(t.tva) },
      { label: 'Net à payer', value: money(t.net), strong: true }
    ];
    const html = docHead('SITUATION DE SOUS-TRAITANT', s.numero, s.date, 'Période : ' + esc(s.periode || '—'), ch) +
      '<div class="doc-parties">' +
        party('Sous-traitant', st ? '<p><strong>' + esc(st.nom) + '</strong><br>' + esc(st.specialite || '') + '<br>' + esc(st.adresse || '') + '<br>' + esc((st.cp || '') + ' ' + (st.ville || '')) + '<br>SIRET ' + esc(st.siret || '') + '</p>' : '<p>—</p>') +
        party('Chantier', ch ? '<p><strong>' + esc(ch.code || '') + '</strong><br>' + esc(ch.nom) + '<br>' + chantierAddress(ch) + '</p>' : '<p>—</p>') +
      '</div>' +
      table(lines, [
        { label: 'Désignation' }, { label: 'Marché HT', r: true }, { label: '% ant.', r: true }, { label: '% cumulé', r: true }, { label: 'Cumulé HT', r: true }, { label: 'Période HT', r: true }
      ]) +
      totals(rows) +
      (s.notes ? '<div class="notes"><strong>Observations :</strong> ' + esc(s.notes) + '</div>' : '') +
      '<div class="notes">' + esc(App.settings().mentionsSituation) + '</div>' +
      '<div class="sign"><div>Le sous-traitant</div><div>Pour ' + esc(soc().nom) + '</div></div>';
    App.printHTML('Situation ' + s.numero, html);
  };

  /* ---------------- Fiche chantier ---------------- */
  App.printChantier = function (id) {
    const ch = App.db.find('chantiers', id);
    if (!ch) return;
    const av = App.avancement(ch);
    const tasks = App.db.get('taches').filter(function (t) { return t.chantierId === ch.id; });
    const devis = App.db.get('devis').filter(function (d) { return d.chantierId === ch.id; });
    const commandes = App.db.get('commandes').filter(function (c) { return c.chantierId === ch.id; });
    const decomptes = App.db.get('decomptes').filter(function (d) { return d.chantierId === ch.id; });
    const ca = App.sum(devis.filter(function (d) { return d.statut === 'Accepté'; }), function (d) { return App.calc.devis(d).ht; });
    const engage = App.sum(commandes.filter(function (c) { return c.statut !== 'Annulé'; }), function (c) { return App.calc.commande(c).ht; });
    const facture = App.sum(decomptes.filter(function (d) { return d.statut === 'Payé' || d.statut === 'Envoyé'; }), function (d) { return App.calc.decompte(d).ht; });
    const lots = (ch.lots || []).map(function (l) {
      return '<tr><td>' + esc(l.nom) + '</td><td class="r">' + num(l.poids) + ' %</td><td class="r">' + num(l.avancement) + ' %</td><td class="r">' + num(App.n(l.poids) * App.n(l.avancement) / 100) + ' %</td></tr>';
    }).join('');
    const taskRows = tasks.map(function (t) {
      return '<tr><td>' + esc(t.nom) + '</td><td>' + esc(t.responsable || '') + '</td><td>' + fmtDate(t.debut) + ' → ' + fmtDate(t.fin) + '</td><td>' + esc(t.statut) + '</td><td class="r">' + num(t.avancement) + ' %</td></tr>';
    }).join('');
    const html = docHead('FICHE CHANTIER', ch.code || '—', App.todayISO(), null, ch) +
      '<div class="doc-parties">' +
        party('Maître d\'ouvrage', '<p><strong>' + esc(ch.client || '—') + '</strong><br>' + esc(ch.contact || '') + '<br>' + esc(ch.tel || '') + (ch.email ? '<br>' + esc(ch.email) : '') + '</p>') +
        party('Chantier', '<p><strong>' + esc(ch.nom) + '</strong><br>' + chantierAddress(ch) + '<br>Conducteur : ' + esc(ch.chef || '—') + '<br>Statut : ' + esc(ch.statut || '—') + '</p>') +
      '</div>' +
      '<div class="kpi-doc"><div><span>Avancement</span><b>' + num(Math.round(av * 10) / 10) + ' %</b></div><div><span>Budget</span><b>' + money(ch.budget) + '</b></div><div><span>Devis acceptés</span><b>' + money(ca) + '</b></div><div><span>Achats engagés</span><b>' + money(engage) + '</b></div><div><span>Facturé</span><b>' + money(facture) + '</b></div></div>' +
      (ch.description ? '<div class="doc-title">Description</div><p>' + esc(ch.description) + '</p>' : '') +
      '<div class="doc-title">Avancement par lot</div>' +
      '<table class="lines"><thead><tr><th>Lot</th><th class="r">Poids</th><th class="r">Avancement</th><th class="r">Contribution</th></tr></thead><tbody>' + (lots || '<tr><td colspan="4">Aucun lot renseigné</td></tr>') + '</tbody></table>' +
      '<div class="doc-title">Planning des tâches</div>' +
      '<table class="lines"><thead><tr><th>Tâche</th><th>Responsable</th><th>Période</th><th>Statut</th><th class="r">Avanc.</th></tr></thead><tbody>' + (taskRows || '<tr><td colspan="5">Aucune tâche</td></tr>') + '</tbody></table>' +
      '<div class="notes">Document généré le ' + fmtDate(App.todayISO()) + ' — ' + esc(soc().nom) + '. Données indicatives à vérifier avant diffusion.</div>';
    App.printHTML('Fiche chantier ' + ch.nom, html);
  };
})();
