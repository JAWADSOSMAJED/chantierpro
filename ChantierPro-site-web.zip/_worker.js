/* =========================================================
   Protection optionnelle par mot de passe — Cloudflare Pages
   ---------------------------------------------------------
   Actif uniquement si la variable d'environnement SITE_PASSWORD
   est définie dans le projet Cloudflare Pages.
   Sans cette variable, le site reste accessible normalement.
   ========================================================= */
export default {
  async fetch(request, env) {
    const password = env && env.SITE_PASSWORD;
    if (!password) return env.ASSETS.fetch(request);

    const header = request.headers.get('Authorization') || '';
    if (header.indexOf('Basic ') !== 0) return unauthorized();

    let decoded = '';
    try {
      decoded = decodeURIComponent(escape(atob(header.slice(6))));
    } catch (e) {
      return unauthorized();
    }
    const given = decoded.slice(decoded.indexOf(':') + 1);
    if (given !== password) return unauthorized();

    return env.ASSETS.fetch(request);
  }
};

function unauthorized() {
  return new Response('Acc\u00e8s prot\u00e9g\u00e9 par mot de passe.', {
    status: 401,
    headers: {
      'WWW-Authenticate': 'Basic realm="ChantierPro", charset="UTF-8"',
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-store'
    }
  });
}
