# ChantierPro — Gestion de chantier BTP

Application web autonome (HTML/CSS/JavaScript) pour piloter un chantier au quotidien :
avancement, planning, fournisseurs, stock, devis, bons de commande, sous-traitants,
décomptes clients et documentation.

Toutes les données sont enregistrées **dans le navigateur** (localStorage). Aucun serveur,
aucune base de données et aucune installation ne sont nécessaires. Une sauvegarde JSON
permet d'archiver ou de transférer les données vers un autre poste.

---

## Ouvrir le site

### 1. Ouverture directe (le plus simple)

Double-cliquez sur **`index.html`**. Le site s'ouvre dans votre navigateur habituel.

### 2. Avec un serveur local (recommandé pour un usage régulier)

Double-cliquez sur **`Ouvrir le site.bat`** : un petit serveur local démarre sur le port 8765
et la page s'ouvre à l'adresse <http://localhost:8765>.

> Le fichier `.bat` utilise Python s'il est installé. Sinon, il ouvre directement `index.html`.
> Pour arrêter le serveur, fermez la fenêtre de commande minimisée « ChantierPro ».

Vous pouvez aussi lancer manuellement, depuis le dossier du site :

```bat
python -m http.server 8765
```

puis ouvrir <http://localhost:8765>.

> **Important :** les données sont liées à l'adresse utilisée. Une base ouverte via
> `file://` et une base ouverte via `http://localhost:8765` sont **deux bases distinctes**.
> Choisissez une méthode d'ouverture et conservez-la. En cas de changement, utilisez
> l'export JSON puis l'import.

---

## Modules disponibles

| Module | Ce que vous pouvez faire |
| --- | --- |
| **Tableau de bord** | KPI de l'activité, chantiers en cours, alertes stock/planning, échéances, derniers mouvements |
| **Chantiers** | Créer, modifier, supprimer un chantier ; fiche détaillée avec budget, avancement, devis, achats, décomptes et documents |
| **Planning** | Vue Gantt des tâches, filtres par statut, création/édition des tâches, statuts et avancement |
| **Avancement** | Lots pondérés modifiables en direct (curseur ou saisie), avancement global recalculé, journal de suivi |
| **Fournisseurs** | Carnet d'adresses complet (contacts, coordonnées, spécialités, notes) |
| **Stock & fournitures** | Articles, seuils d'alerte, valeur du stock, entrées/sorties, historique des mouvements |
| **Bons de commande** | Création avec lignes et totaux automatiques, duplication, impression, statuts de livraison |
| **Devis** | Chiffrage avec remise, TVA et totaux en direct, duplication, impression, création d'un bon de commande depuis un devis |
| **Décomptes clients** | Situations de travaux, avancement par ligne, retenue de garantie, TVA, net à payer, impression |
| **Sous-traitants** | Fiches partenaires, suivi de l'assurance décennale, marchés sous-traités |
| **Situations ST** | Cumulé, période, retenue, TVA et net à payer calculés automatiquement ; validation et paiement |
| **Documentation** | Contrats, plans, PV, assurances, factures ; classement par **sous-onglets** (Bureau d'étude, Topographe, Laboratoire, Divers, Maître d'ouvrage), version, expiration, lien ou pièce jointe, aperçu |
| **Paramètres** | Logo de l'entreprise, identité, TVA et retenue par défaut, mentions imprimées, sauvegarde/restauration, aide |

Les listes tabulaires proposent la recherche, le tri par colonne, la modification et la suppression.
Les chantiers s'affichent sous forme de cartes avec filtres par statut et accès direct à la fiche.
Le sélecteur **Chantier** de la barre supérieure filtre la plupart des modules.

La page **Documentation** est organisée en **sous-onglets** : *Bureau d'étude*,
*Topographe*, *Laboratoire*, *Divers* et *Maître d'ouvrage*. Chaque sous-onglet affiche
un compteur de documents. Le bouton **Sous-onglet** de la barre d'outils permet d'en
créer de nouveaux ; ils sont enregistrés dans les paramètres et proposés lors de la
création d'un document. Le sous-onglet actif est utilisé par défaut pour tout nouveau
document.

### Sur téléphone et tablette

L'interface s'adapte automatiquement aux petits écrans :

- menu latéral escamotable (bouton ☰, fermeture par la croix, le fond ou la touche Échap) ;
- barre supérieure sur deux lignes : titre, bouton **Nouveau** et filtre chantier accessibles au pouce ;
- les tableaux deviennent des **cartes** lisibles, avec le libellé de chaque valeur ;
- un sélecteur **Trier** remplace le clic sur les en-têtes de colonnes ;
- les fenêtres de formulaire s'ouvrent en **panneau bas**, avec défilement interne et boutons pleine largeur ;
- champs de saisie à 16 px (pas de zoom automatique sur iPhone) et boutons d'au moins 44 px ;
- le planning (Gantt) reste consultable par défilement horizontal.

Le site peut être **installé sur l'écran d'accueil** (Safari : *Partager → Sur l'écran d'accueil* ;
Chrome Android : *⋮ → Installer l'application*). Il s'ouvre alors en plein écran et conserve
les données du navigateur.

---

## Sauvegarde et restauration

- **Exporter** : bouton *Exporter* de la barre supérieure, ou *Paramètres → Exporter une sauvegarde JSON*.
  Un fichier `chantierpro-sauvegarde-AAAA-MM-JJ.json` est téléchargé.
- **Importer** : *Paramètres → Importer une sauvegarde*, puis choisissez le fichier JSON.
  Les données actuelles sont remplacées.
- **Recharger la démonstration** : remet le jeu de données d'exemple.
- **Tout effacer** : vide toutes les données (action définitive, à confirmer).

> Les données restent sur le poste et dans le navigateur utilisé. Vider les données du site
> ou utiliser un autre navigateur/profil revient à repartir d'une base vide : exportez
> régulièrement une sauvegarde.

### Pièces jointes

Les documents acceptent un fichier de **1,5 Mo maximum**, stocké en base64 dans le navigateur.
Pour les fichiers plus volumineux, renseignez plutôt un **lien** (URL ou chemin réseau).
Le stockage local du navigateur étant limité, préférez les liens pour les gros plans et PDF.

---

## Logo et devise

- **Logo** : le fichier `assets/logo.jpg` est affiché par défaut dans la barre latérale, sur
  l'écran de verrouillage, dans l'onglet du navigateur (favicon) et en en-tête de tous les
  documents imprimés (devis, bons de commande, décomptes, situations et fiche chantier).
  Pour le remplacer, allez dans *Paramètres → Identité de l'entreprise → Choisir un logo*
  (PNG, JPG, SVG ou WebP, **1 Mo maximum**). Le bouton *Retirer* le supprime.
- **Devise** : tous les montants de l'application et des documents imprimés sont exprimés
  en **dirham marocain (MAD)**.

---

## Protection par mot de passe

L'application intègre un **verrouillage local** : *Paramètres → Protection par mot
de passe*. Définissez un mot de passe (4 caractères minimum) puis choisissez
« Activer le verrouillage ». Il sera demandé à chaque nouvelle ouverture du site, sur
ce navigateur. Les boutons « Verrouiller maintenant », « Changer le mot de passe » et
« Désactiver le verrouillage » sont disponibles dans la même section.

Une fois le verrouillage activé, l'option **« Demander le mot de passe à chaque
modification »** (activée par défaut) demande une confirmation avant chaque action qui
modifie les données :

- enregistrement d'un formulaire (chantier, tâche, devis, bon de commande, décompte,
  situation, fournisseur, article, document…) ;
- suppression d'une ligne, d'un lot, d'un mouvement de stock ou d'une entrée du journal ;
- duplication d'un devis ou d'un bon de commande, création d'un BC depuis un devis ;
- boutons « Valider », « Marquer payée », « Marquer payé » ;
- import d'une sauvegarde JSON, rechargement de la démonstration, effacement total ;
- modification des paramètres et du logo de l'entreprise.

La fenêtre de confirmation possède son propre champ : le formulaire en cours reste
ouvert et les valeurs saisies sont conservées. Une annulation ou un mot de passe
incorrect laisse les données intactes. Pour ne demander le mot de passe qu'à
l'ouverture, décochez l'option dans *Paramètres → Protection par mot de passe*.

- Le mot de passe n'est **jamais enregistré en clair** (empreinte SHA-256 salée).
- Il **ne figure pas dans les sauvegardes JSON** exportées.
- En cas d'oubli, les données locales de ce navigateur ne sont plus accessibles.

> **Limite importante** : c'est une protection de l'interface, pas un chiffrement.
> Elle empêche un utilisateur occasionnel d'ouvrir l'application, mais pas une personne
> technicienne d'accéder aux fichiers ou au stockage du navigateur. Pour restreindre
> réellement l'accès à un site publié, protégez-le chez l'hébergeur (Cloudflare Access
> par exemple). Voir `PUBLIER.md`.

---

## Impression

Les boutons d'impression (devis, bon de commande, décompte, situation sous-traitant, fiche
chantier) ouvrent une fenêtre A4 prête à imprimer ou à enregistrer en PDF.
Si rien ne s'ouvre, autorisez les fenêtres pop-up pour le site.

---

## Structure du projet

```
GestionChantierWeb/
├─ index.html               Page unique et chargement des scripts
├─ Ouvrir le site.bat       Démarrage optionnel d'un serveur local
├─ README.md                Ce fichier
├─ PUBLIER.md               Guide de mise en ligne (Cloudflare, GitHub Pages, FTP, réseau local)
├─ _worker.js               Protection optionnelle du site publié (Cloudflare Pages, variable SITE_PASSWORD)
├─ assets/
│  ├─ styles.css            Design complet (responsive, impression, modales)
│  ├─ icon.svg              Icône PWA (écran d'accueil)
│  └─ logo.jpg              Logo de l'entreprise (remplaçable via Paramètres)
├─ manifest.webmanifest     Manifest de l'application installable
└─ js/
   ├─ core.js               Utilitaires, icônes, modales, formulaires, éditeur de lignes, impression
   ├─ db.js                 Données de démonstration, localStorage, calculs, alertes, import/export
   ├─ security.js           Verrouillage par mot de passe (SHA-256, écran de déverrouillage)
   ├─ list.js               Listes génériques, formulaires et cartes chantier
   ├─ docs-print.js         Modèles imprimables (devis, BC, décomptes, situations, fiche chantier)
   ├─ views-main.js         Tableau de bord, chantiers, fiche chantier
   ├─ views-planning.js     Gantt et avancement par lot + journal
   ├─ views-business.js     Fournisseurs, stock, bons de commande, documentation
   ├─ views-devis.js        Devis et décomptes clients
   ├─ views-st.js           Sous-traitants, situations ST, paramètres et sauvegarde
   └─ boot.js               Navigation, filtre chantier, routage et initialisation
```

Technologies : HTML5, CSS3 et JavaScript natif (aucune dépendance, aucun build).
Compatible avec les navigateurs récents (Chrome, Edge, Firefox).

---

## Bonnes pratiques

1. Ouvrez toujours le site de la même façon (fichier ou serveur local) pour retrouver vos données.
2. Exportez une sauvegarde JSON avant toute modification importante ou mise à jour.
3. Renseignez l'identité de l'entreprise dans **Paramètres** : elle apparaît sur tous les documents imprimés.
4. Mettez à jour l'avancement par lot dans **Avancement** : l'avancement global et les fiches chantier se recalculent automatiquement.
5. Vérifiez les alertes du tableau de bord (stock bas, tâches en retard, assurances, documents expirés).

---

Version 1.2.3 — ChantierPro · Gestion de chantier BTP
